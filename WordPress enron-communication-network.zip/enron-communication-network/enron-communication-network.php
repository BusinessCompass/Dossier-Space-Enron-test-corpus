<?php
/**
 * Plugin Name: Enron Communication Network POC
 * Description: Adds the [enron_communication_network] shortcode and loads its JavaScript and CSS through the WordPress enqueue system.
 * Version: 0.1.0
 * Author: Dossier Space
 * License: GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function dossier_enron_network_enqueue_assets() {
	$plugin_path = plugin_dir_path( __FILE__ );
	$plugin_url  = plugin_dir_url( __FILE__ );
	$style_path = $plugin_path . 'assets/enron-network.css';
	$script_path = $plugin_path . 'assets/enron-network.js';

	wp_enqueue_style(
		'dossier-enron-network',
		$plugin_url . 'assets/enron-network.css',
		array(),
		(string) filemtime( $style_path )
	);

	wp_enqueue_script(
		'dossier-enron-network',
		$plugin_url . 'assets/enron-network.js',
		array(),
		(string) filemtime( $script_path ),
		true
	);
}
add_action( 'wp_enqueue_scripts', 'dossier_enron_network_enqueue_assets' );

function dossier_enron_network_shortcode() {
	$template = plugin_dir_path( __FILE__ ) . 'templates/network.html';

	if ( ! is_readable( $template ) ) {
		return '<p role="alert">Communication network template is unavailable.</p>';
	}

	return (string) file_get_contents( $template );
}
add_shortcode( 'enron_communication_network', 'dossier_enron_network_shortcode' );
