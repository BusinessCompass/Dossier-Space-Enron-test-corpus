# Enron Communication Network POC — WordPress plugin

This package avoids executable JavaScript in page content. WordPress loads the
JavaScript and stylesheet as plugin assets using `wp_enqueue_script()` and
`wp_enqueue_style()` on the front-end enqueue hook.

## Install

1. In WordPress, open **Plugins > Add New > Upload Plugin**.
2. Upload `enron-communication-network.zip`.
3. Activate **Enron Communication Network POC**.
4. Add a Shortcode block to the target page containing:

   `[enron_communication_network]`

5. Remove the earlier network HTML, CSS, and JavaScript from page-builder
   panels, publish the page, and clear page/cache-plugin caches.

The plugin has no external library or network dependency. Its JavaScript is
loaded in the footer and its file modification time is used as the version so
asset changes invalidate caches.

## Files

- `enron-communication-network.php` — plugin registration, enqueue calls, and shortcode.
- `templates/network.html` — non-executable page markup.
- `assets/enron-network.css` — scoped presentation.
- `assets/enron-network.js` — interactive network behavior and embedded pilot data.

## Scope

This remains the bounded Session 20 proof of concept. It is an orientation aid,
not a full-corpus or wrongdoing inference.
