<?php
/**
 * Plugin Name: Dossier Concept Simulator
 * Description: Explore the source-backed 19-record Dossier Space concept map with the [dossier_concept_simulator] shortcode or Tools page.
 * Version: 1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: Dossier Space
 * License: GPL-2.0-or-later
 * Text Domain: dossier-concept-simulator
 */
if (!defined('ABSPATH')) { exit; }

function dcs24_enqueue_assets() {
    if (!current_user_can('manage_options')) { return; }
    $url = plugin_dir_url(__FILE__);
    wp_enqueue_style('dcs24-map', $url . 'assets/simulator.css', array(), '1.0.0');
    wp_enqueue_script('dcs24-map', $url . 'assets/simulator.js', array(), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'dcs24_enqueue_assets');

function dcs24_render() {
    if (!current_user_can('manage_options')) {
        return '<p>Dossier Concept Simulator is available to signed-in administrators.</p>';
    }
    static $data = null;
    if ($data === null) { $data = require __DIR__ . '/includes/data.php'; }
    if (!is_array($data)) { return '<p role="alert">Concept map data is unavailable.</p>'; }
    $json = wp_json_encode($data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    if ($json === false) { return '<p role="alert">Concept map data could not be encoded.</p>'; }
    $id = wp_unique_id('dcs24-');
    return '<section id="' . esc_attr($id) . '" class="dcs24" aria-label="Dossier concept simulator">'
        . '<noscript>Enable JavaScript to explore the concept map.</noscript>'
        . '<script type="application/json" class="dcs24-data">' . $json . '</script></section>';
}
add_shortcode('dossier_concept_simulator', 'dcs24_render');

function dcs24_admin_menu() {
    add_management_page('Dossier Concept Simulator', 'Concept Simulator', 'manage_options', 'dossier-concept-simulator', 'dcs24_admin_page');
}
add_action('admin_menu', 'dcs24_admin_menu');
function dcs24_admin_assets($hook) {
    if ($hook === 'tools_page_dossier-concept-simulator') { dcs24_enqueue_assets(); }
}
add_action('admin_enqueue_scripts', 'dcs24_admin_assets');
function dcs24_admin_page() {
    if (!current_user_can('manage_options')) { return; }
    echo '<div class="wrap">';
    // Rendered markup contains only fixed HTML and safely encoded source-derived JSON.
    echo dcs24_render();
    echo '</div>';
}
