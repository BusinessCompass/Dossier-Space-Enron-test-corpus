(() => {
 'use strict';
 const NS='http://www.w3.org/2000/svg';
 const positions={C05:[40,35],C01:[385,35],C06:[730,35],C02:[40,210],C03:[385,210],C08:[730,210],C04:[40,385],C12:[385,385],C07:[730,385],C09:[40,595],C10:[385,595],C11:[730,595]};
 const short={C01:['Agreement','lifecycle'],C02:['Document availability','and completeness'],C03:['Follow-up','and handover'],C04:['Identity and','communication routing'],C05:['Trade and volume','reconciliation'],C06:['Regulatory response','and filing'],C07:['Scheduling and','coordination'],C08:['Employee','learning'],C09:['Distress','expectations'],C10:['Third-party','news'],C11:['Time-exception','reporting'],C12:['Personal and civic','communication']};
 const node=(tag,attrs={},text)=>{const n=document.createElement(tag);Object.entries(attrs).forEach(([k,v])=>n.setAttribute(k,v));if(text!==undefined)n.textContent=text;return n;};
 const svg=(tag,attrs={},text)=>{const n=document.createElementNS(NS,tag);Object.entries(attrs).forEach(([k,v])=>n.setAttribute(k,v));if(text!==undefined)n.textContent=text;return n;};
 function init(root){
  if(root.dataset.ready)return;
  const source=root.querySelector('.dcs24-data');if(!source)return;
  let data;try{data=JSON.parse(source.textContent);}catch(e){root.textContent='The concept-map dataset could not be read.';return;}
  root.dataset.ready='true';
  const concepts=new Map(data.concepts.map(c=>[c.id,c]));const records=new Map(data.records.map(r=>[r.id,r]));
  const state={included:new Set(data.records.map(r=>r.id)),mailbox:'all',minimum:1,uncertain:false,query:'',selected:{kind:'concept',id:'C02'},tab:'map'};
  root.insertAdjacentHTML('beforeend',`<header class="dcs-head"><div><div class="dcs-kicker">DOSSIER SPACE / CONCEPT LAB</div><h2>Concepts in context<span class="dcs-dot">.</span></h2><p>A source-backed map. Change the sample, then inspect what remains.</p></div><div class="dcs-session">S24 <span>WORKED EXAMPLE</span></div></header>
  <div class="dcs-controls"><label>Find a concept<input type="search" class="dcs-search" placeholder="Agreement, scheduling…"></label><label>Mailbox<select class="dcs-mailbox"><option value="all">All three mailboxes</option><option value="bailey-s">Bailey</option><option value="rapp-b">Rapp</option><option value="pereira-s">Pereira</option></select></label><label>Records per concept <output class="dcs-min-value">1+</output><input class="dcs-min" type="range" min="1" max="6" value="1"></label><label class="dcs-check"><input class="dcs-uncertain" type="checkbox">Hide forecast / possibility excerpts</label><button type="button" class="dcs-reset">Restore all</button></div>
  <div class="dcs-stats" role="status" aria-live="polite"></div><div class="dcs-tabs" role="tablist" aria-label="Explorer view"><button type="button" role="tab" data-tab="map">Map</button><button type="button" role="tab" data-tab="evidence">Evidence</button><button type="button" role="tab" data-tab="sample">Sample simulator</button></div>
  <div class="dcs-body"><div class="dcs-main"><section class="dcs-map-panel" role="tabpanel"><div class="dcs-chart-caption"><strong>Click a concept or a relationship number</strong><span>Arrows are labelled associations, not causal findings.</span></div><div class="dcs-graph"></div><div class="dcs-empty" hidden>No concepts meet these filters. Lower the threshold or restore the sample.</div><details class="dcs-relation-list"><summary>Explore relationships as a list</summary><div></div></details></section><section class="dcs-evidence-panel" role="tabpanel" hidden></section><section class="dcs-sample-panel" role="tabpanel" hidden><div class="dcs-sample-title"><div><h3>What if these records were absent?</h3><p>Changes affect this view only. No source or finding is rewritten.</p></div><div class="dcs-presets"><button type="button" data-preset="baseline">Original 4</button><button type="button" data-preset="all">All 19</button><button type="button" data-preset="none">Clear</button></div></div><div class="dcs-record-list"></div></section></div><aside class="dcs-detail" aria-label="Selection details"></aside></div>
  <footer class="dcs-footer"><span>19-record convenience sample · Self-checked · No independent assurance</span><span>Attachments excluded · Simulation stays in your browser</span><details><summary>Method and source attribution</summary><p>Four inherited records plus 15 additional records, across Bailey, Rapp and Pereira. Concepts are analyst-defined. Quotes retain requests, denials, forecasts and attribution. A relationship is visible only when every cited evidence excerpt and both concepts remain visible. Filters do not establish real-world truth or independence. Counts are distinct sampled records, not people or events.</p><p>Dataset: EDRM Enron, ZL Technologies, Inc. (www.zlti.com), CC BY 3.0 US per source footer. This interface contains the reviewed excerpts and source locators, not raw messages or attachments.</p></details></footer>`);
  const q=s=>root.querySelector(s);let computed;
  const onActivate=(element,callback)=>{element.addEventListener('click',callback);element.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();callback();}});};
  function derive(){
   const active=data.records.filter(r=>state.included.has(r.id)&&(state.mailbox==='all'||r.mailbox===state.mailbox));const activeIds=new Set(active.map(r=>r.id));
   const evidence=data.evidence.filter(e=>activeIds.has(e.record)&&(!state.uncertain||!(/forecast|possibility/i.test(e.type))));
   const support=new Map(data.concepts.map(c=>[c.id,new Set(evidence.filter(e=>e.concepts.includes(c.id)).map(e=>e.record))]));
   const visible=data.concepts.filter(c=>support.get(c.id).size>=state.minimum&&(!state.query||(c.label+' '+c.definition).toLowerCase().includes(state.query.toLowerCase())));
   const visibleIds=new Set(visible.map(c=>c.id));const evIds=new Set(evidence.map(e=>e.id));
   const edges=data.relationships.filter(e=>visibleIds.has(e.source)&&visibleIds.has(e.target)&&e.evidence.every(id=>evIds.has(id)));
   return {active,evidence,support,visible,visibleIds,edges,displayEvidence:evidence.filter(e=>e.concepts.some(c=>visibleIds.has(c)))};
  }
  function select(kind,id){state.selected={kind,id};render();}
  function renderGraph(){
   const wrap=q('.dcs-graph');wrap.replaceChildren();const chart=svg('svg',{viewBox:'0 0 1040 710',role:'group','aria-label':'Interactive concept map. Tab to concepts and numbered relationships.'});wrap.append(chart);
   const defs=svg('defs');const arrow=svg('marker',{id:root.id+'-arrow',viewBox:'0 0 10 10',refX:9,refY:5,markerWidth:7,markerHeight:7,orient:'auto-start-reverse'});arrow.append(svg('path',{d:'M 0 0 L 10 5 L 0 10 z',fill:'currentColor'}));defs.append(arrow);chart.append(defs);
   for(const edge of computed.edges){
    let [sx,sy]=positions[edge.source], [tx,ty]=positions[edge.target];sx+=135;sy+=46;tx+=135;ty+=46;
    const dx=tx-sx,dy=ty-sy;const horizontal=Math.abs(dx)>Math.abs(dy);if(horizontal){sx+=Math.sign(dx)*135;tx-=Math.sign(dx)*135;}else{sy+=Math.sign(dy)*46;ty-=Math.sign(dy)*46;}
    const d=edge.id==='R06'?'M 1000 81 L 1020 81 L 1020 431 L 1000 431':`M ${sx} ${sy} L ${tx} ${ty}`;const selected=state.selected.kind==='edge'&&state.selected.id===edge.id;
    const g=svg('g',{class:'dcs-edge'+(selected?' is-selected':''),role:'button',tabindex:0,'aria-label':`${edge.id}: ${concepts.get(edge.source).label} ${edge.verb} ${concepts.get(edge.target).label}`,'data-focus':'edge-'+edge.id});
    g.append(svg('path',{d,class:'dcs-edge-hit'}));g.append(svg('path',{d,class:'dcs-edge-line','marker-end':edge.id==='R05'?'':`url(#${root.id}-arrow)`}));
    const mx=edge.id==='R06'?1015:(sx+tx)/2,my=edge.id==='R06'?347:(sy+ty)/2;g.append(svg('rect',{x:mx-22,y:my-13,width:44,height:26,rx:13,class:'dcs-edge-badge'}));g.append(svg('text',{x:mx,y:my+4,'text-anchor':'middle'},edge.id));g.append(svg('title',{},edge.verb));onActivate(g,()=>select('edge',edge.id));chart.append(g);
   }
   chart.append(svg('text',{x:40,y:565,class:'dcs-isolated-label'},'SEPARATE CONCEPTS · no relationship asserted in this map'));
   for(const c of data.concepts){
    if(!computed.visibleIds.has(c.id))continue;
    const [x,y]=positions[c.id];const selected=state.selected.kind==='concept'&&state.selected.id===c.id;
    const g=svg('g',{class:'dcs-node'+(selected?' is-selected':''),transform:`translate(${x},${y})`,role:'button',tabindex:0,'aria-pressed':String(selected),'aria-label':`${c.label}, ${computed.support.get(c.id).size} supporting records`,'data-focus':'concept-'+c.id});
    g.append(svg('rect',{width:270,height:92,rx:13}));g.append(svg('text',{x:18,y:23,class:'dcs-node-id'},c.id));g.append(svg('text',{x:250,y:24,'text-anchor':'end',class:'dcs-node-count'},`${computed.support.get(c.id).size} records`));
    short[c.id].forEach((line,i)=>g.append(svg('text',{x:18,y:50+i*21,class:'dcs-node-label'},line)));onActivate(g,()=>select('concept',c.id));chart.append(g);
   }
   q('.dcs-empty').hidden=computed.visible.length!==0;
   const list=q('.dcs-relation-list div');list.replaceChildren();for(const e of computed.edges){const b=node('button',{type:'button','data-focus':'list-'+e.id},`${e.id} · ${concepts.get(e.source).label} → ${e.verb} → ${concepts.get(e.target).label}`);b.addEventListener('click',()=>select('edge',e.id));list.append(b);}if(!computed.edges.length)list.append(node('p',{},'No fully supported relationships in the current view.'));
  }
  function evidenceCard(e){
   const card=node('article',{class:'dcs-evidence-card'});const top=node('div',{class:'dcs-card-top'});top.append(node('span',{class:'dcs-id'},e.id+' / '+e.record),node('span',{class:'dcs-type'},e.type));card.append(top,node('blockquote',{},e.quote),node('p',{class:'dcs-limit'},e.limit));
   const b=node('button',{type:'button',class:'dcs-source-button','data-focus':'source-'+e.id},'Source record ↗');b.addEventListener('click',()=>select('record',e.record));card.append(b);return card;
  }
  function renderDetails(){
   const panel=q('.dcs-detail');panel.replaceChildren();const s=state.selected;
   if(s.kind==='concept'){
    const c=concepts.get(s.id);panel.append(node('div',{class:'dcs-kicker'},'CONCEPT / '+c.id),node('h3',{},c.label),node('p',{},c.definition));
    if(!computed.visibleIds.has(c.id))panel.append(node('p',{class:'dcs-notice'},'This concept is outside the current filters. Restore the sample or adjust the filters to view its evidence.'));
    const es=computed.visibleIds.has(c.id)?computed.evidence.filter(e=>e.concepts.includes(c.id)):[];
    panel.append(node('h4',{},`${new Set(es.map(e=>e.record)).size} supporting records · ${es.length} excerpts`));es.forEach(e=>panel.append(evidenceCard(e)));
   }else if(s.kind==='edge'){
    const e=data.relationships.find(x=>x.id===s.id);panel.append(node('div',{class:'dcs-kicker'},'RELATIONSHIP / '+e.id),node('h3',{},concepts.get(e.source).label),node('p',{class:'dcs-verb'},e.verb),node('h3',{},concepts.get(e.target).label),node('p',{},e.limit));
    if(!computed.edges.some(x=>x.id===e.id)){panel.append(node('p',{class:'dcs-notice'},'This relationship is no longer fully supported under the current filters.'));return;}
    data.evidence.filter(x=>e.evidence.includes(x.id)).forEach(x=>panel.append(evidenceCard(x)));
   }else{
    const record=records.get(s.id);panel.append(node('div',{class:'dcs-kicker'},'SOURCE RECORD / '+record.id),node('h3',{},record.subject),node('p',{},record.kind+' · '+record.mailbox),node('p',{},record.date));
    if(!computed.active.some(x=>x.id===s.id))panel.append(node('p',{class:'dcs-notice'},'Excluded from the current simulation. Source identifiers below remain available for traceability.'));
    for(const [label,value] of [['Archive',record.archive],['Entry',record.entry],['SHA-256 of source EML',record.sha256]])panel.append(node('h4',{},label),node('code',{class:'dcs-locator'},value));
    panel.append(node('p',{class:'dcs-limit'},'Locate this archive entry in the Dossier Space source corpus. Raw email and attachments are not bundled in this plugin.'));
   }
  }
  function renderEvidence(){const p=q('.dcs-evidence-panel');p.replaceChildren(node('h3',{},'Evidence in the current view'),node('p',{},'Statements retain their type and interpretation limits. Quotes are not independent verification of their claims.'));computed.displayEvidence.forEach(e=>p.append(evidenceCard(e)));if(!computed.displayEvidence.length)p.append(node('p',{class:'dcs-notice'},'No evidence matches these filters.'));}
  function renderSample(){
   const p=q('.dcs-record-list');p.replaceChildren();for(const r of data.records){const row=node('div',{class:'dcs-record'});const label=node('label');const input=node('input',{type:'checkbox','data-focus':'record-'+r.id,'aria-label':'Include '+r.id});input.checked=state.included.has(r.id);input.addEventListener('change',()=>{input.checked?state.included.add(r.id):state.included.delete(r.id);render();});label.append(input,node('strong',{},r.id),node('span',{},r.mailbox+(r.baseline?' · original':'')));const b=node('button',{type:'button','data-focus':'inspect-'+r.id},r.subject);b.addEventListener('click',()=>select('record',r.id));row.append(label,b,node('small',{},r.kind));p.append(row);}
  }
  function render(){
   const focus=document.activeElement?.getAttribute('data-focus');computed=derive();q('.dcs-min-value').textContent=state.minimum+'+';
   q('.dcs-stats').replaceChildren();for(const [count,label] of [[computed.active.length,'of 19 records'],[computed.visible.length,'of 12 concepts'],[computed.edges.length,'of 9 relationships']]){const item=node('div');item.append(node('strong',{},String(count)),node('span',{},label));q('.dcs-stats').append(item);}q('.dcs-stats').append(node('p',{},'WHAT-IF VIEW · source findings remain unchanged'));
   renderGraph();renderDetails();renderEvidence();renderSample();
   root.querySelectorAll('[data-tab]').forEach((b,i)=>{const chosen=b.dataset.tab===state.tab;b.id=root.id+'-tab-'+b.dataset.tab;b.setAttribute('aria-selected',String(chosen));b.setAttribute('aria-controls',root.id+'-panel-'+b.dataset.tab);b.tabIndex=chosen?0:-1;const panel=q('.dcs-'+b.dataset.tab+'-panel');panel.id=root.id+'-panel-'+b.dataset.tab;panel.setAttribute('aria-labelledby',b.id);panel.hidden=!chosen;});
   if(focus)root.querySelector(`[data-focus="${focus}"]`)?.focus({preventScroll:true});
  }
  q('.dcs-search').addEventListener('input',e=>{state.query=e.target.value;render();});q('.dcs-mailbox').addEventListener('change',e=>{state.mailbox=e.target.value;render();});q('.dcs-min').addEventListener('input',e=>{state.minimum=Number(e.target.value);render();});q('.dcs-uncertain').addEventListener('change',e=>{state.uncertain=e.target.checked;render();});
  q('.dcs-reset').addEventListener('click',()=>{state.included=new Set(data.records.map(r=>r.id));state.minimum=1;state.mailbox='all';state.query='';state.uncertain=false;state.selected={kind:'concept',id:'C02'};q('.dcs-search').value='';q('.dcs-mailbox').value='all';q('.dcs-min').value=1;q('.dcs-uncertain').checked=false;render();});
  root.querySelectorAll('[data-preset]').forEach(b=>b.addEventListener('click',()=>{state.included=new Set(b.dataset.preset==='none'?[]:data.records.filter(r=>b.dataset.preset==='all'||r.baseline).map(r=>r.id));render();}));
  const tabs=[...root.querySelectorAll('[data-tab]')];tabs.forEach((b,i)=>{b.addEventListener('click',()=>{state.tab=b.dataset.tab;render();});b.addEventListener('keydown',e=>{let j;if(e.key==='ArrowRight')j=(i+1)%tabs.length;if(e.key==='ArrowLeft')j=(i+tabs.length-1)%tabs.length;if(e.key==='Home')j=0;if(e.key==='End')j=tabs.length-1;if(j!==undefined){e.preventDefault();state.tab=tabs[j].dataset.tab;render();tabs[j].focus();}});});render();
 }
 const start=()=>document.querySelectorAll('.dcs24').forEach(init);
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
})();
