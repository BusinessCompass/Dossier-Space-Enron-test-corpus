=== Dossier Concept Simulator ===
Contributors: dossier-space
Requires at least: 6.0
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

Interactive source-backed concept mapping with a reversible sample simulator.

== Installation ==
Upload the ZIP under Plugins, activate it, then open Tools > Concept Simulator as an administrator. Optional shortcode: [dossier_concept_simulator]. See README.md for details and validation limits.

== Changelog ==
= 1.0.0 =
Initial 19-record S24 map, evidence drill-down, sample exclusions, local filters and offline preview.
